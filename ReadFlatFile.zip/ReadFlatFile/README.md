# ReadFlatFile
Test version of the flat file generator and search engine. C# implementation

>   * [x]  Generator;
>   * [x]  Search Engine (2 versions);
>   * [x]  GUI;
